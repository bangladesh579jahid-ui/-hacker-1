# 🔥 FF Hack Panel v2.0

## Termux দিয়ে রান করো

```bash
pkg install python
pip install flask
cd backend
python app.py
```

তারপর ব্রাউজারে যাও: http://localhost:5000

## APK বানাতে চাইলে
WebIntoApp.com → URL দাও → APK নামাও
